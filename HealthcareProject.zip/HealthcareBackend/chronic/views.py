from django.shortcuts import render, redirect,get_object_or_404
from .forms import RegistrationForm, LoginForm
from django.contrib.auth import logout as django_logout
from .models import UserProfile
from .forms import UserProfileForm
from .models import Doctor, Hospital
from .forms import DoctorForm, HospitalForm
from django.contrib.auth.decorators import login_required


# Admin credentials
ADMIN_EMAIL = 'admin123@gmail.com'
ADMIN_PASSWORD = '123'
ADMIN_NAME = 'admin'

def home(request):
    return render(request, 'chronic/home.html')

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegistrationForm()
    return render(request, 'chronic/register.html', {'form': form})

def login_view(request):
    error = ''
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']

            if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
                request.session['is_admin'] = True  # optional
                return render(request, 'chronic/admin_dashboard.html', {'name': ADMIN_NAME})

            try:
                user = UserProfile.objects.get(email=email, password=password)
                request.session['user_id'] = user.id  # ✅ Store user ID in session
                return redirect('user_dashboard')  # ✅ Redirect to dashboard
            except UserProfile.DoesNotExist:
                error = 'Invalid credentials'
    else:
        form = LoginForm()
    return render(request, 'chronic/login.html', {'form': form, 'error': error})


def logout_view(request):
    django_logout(request)
    return redirect('login')  # or 'home' if you prefer

# Doctor
def add_doctor(request):
    form = DoctorForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        return redirect('doctor_list')
    return render(request, 'chronic/add_doctor.html', {'form': form})

def doctor_list(request):
    doctors = Doctor.objects.all()
    return render(request, 'chronic/doctor_list.html', {'doctors': doctors})

def edit_doctor(request, pk):
    doctor = get_object_or_404(Doctor, pk=pk)
    form = DoctorForm(request.POST or None, request.FILES or None, instance=doctor)
    if form.is_valid():
        form.save()
        return redirect('doctor_list')
    return render(request, 'chronic/add_doctor.html', {'form': form})

def delete_doctor(request, pk):
    doctor = get_object_or_404(Doctor, pk=pk)
    doctor.delete()
    return redirect('doctor_list')

# Hospital (similar pattern)
def add_hospital(request):
    form = HospitalForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        return redirect('hospital_list')
    return render(request, 'chronic/add_hospital.html', {'form': form})

def hospital_list(request):
    hospitals = Hospital.objects.all()
    return render(request, 'chronic/hospital_list.html', {'hospitals': hospitals})

def edit_hospital(request, pk):
    hospital = get_object_or_404(Hospital, pk=pk)
    form = HospitalForm(request.POST or None, request.FILES or None, instance=hospital)
    if form.is_valid():
        form.save()
        return redirect('hospital_list')
    return render(request, 'chronic/add_hospital.html', {'form': form})

def delete_hospital(request, pk):
    hospital = get_object_or_404(Hospital, pk=pk)
    hospital.delete()
    return redirect('hospital_list')

def admin_dashboard(request):
    doctors = Doctor.objects.all()
    hospitals = Hospital.objects.all()
    return render(request, 'chronic/admin_dashboard.html', {
        'doctors': doctors,
        'hospitals': hospitals,
    })
    
def user_doctor_list(request):
    doctors = Doctor.objects.all()
    return render(request, 'chronic/user_doctor_list.html', {'doctors': doctors})


def user_hospital_list(request):
    hospitals = Hospital.objects.all()
    return render(request, 'chronic/user_hospital_list.html', {'hospitals': hospitals})
    
def manage_users(request):
    users = UserProfile.objects.all()
    return render(request, 'chronic/manage_users.html', {'users': users})

def add_user(request):
    form = UserProfileForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('manage_users')
    return render(request, 'chronic/add_user.html', {'form': form})

def edit_user(request, pk):
    user = get_object_or_404(UserProfile, pk=pk)
    form = UserProfileForm(request.POST or None, instance=user)
    if form.is_valid():
        form.save()
        return redirect('manage_users')
    return render(request, 'chronic/add_user.html', {'form': form})

def delete_user(request, pk):
    user = get_object_or_404(UserProfile, pk=pk)
    user.delete()
    return redirect('manage_users')

def user_profile(request):
    user_id = request.session.get('user_id')

    if not user_id:
        # If user is not logged in, redirect to login
        return redirect('login')

    try:
        user = UserProfile.objects.get(id=user_id)
    except UserProfile.DoesNotExist:
        return redirect('login')

    return render(request, 'chronic/user_profile.html', {'user': user})

def user_dashboard(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('login')

    try:
        user = UserProfile.objects.get(id=user_id)
    except UserProfile.DoesNotExist:
        return redirect('login')

    return render(request, 'chronic/user_dashboard.html', {'user': user})






