from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    
    path('add-doctor/', views.add_doctor, name='add_doctor'),
    path('edit-doctor/<int:pk>/', views.edit_doctor, name='edit_doctor'),
    path('delete-doctor/<int:pk>/', views.delete_doctor, name='delete_doctor'),
    path('doctors/', views.doctor_list, name='doctor_list'),

    path('add-hospital/', views.add_hospital, name='add_hospital'),
    path('edit-hospital/<int:pk>/', views.edit_hospital, name='edit_hospital'),
    path('delete-hospital/<int:pk>/', views.delete_hospital, name='delete_hospital'),
    path('hospitals/', views.hospital_list, name='hospital_list'),
    
    path('manage-users/', views.manage_users, name='manage_users'),
    path('add-user/', views.add_user, name='add_user'),
    path('edit-user/<int:pk>/', views.edit_user, name='edit_user'),
    path('delete-user/<int:pk>/', views.delete_user, name='delete_user'),
    
    path('user/dashboard/', views.user_dashboard, name='user_dashboard'),
    path('user/profile/', views.user_profile, name='user_profile'),
    path('user/doctors/', views.user_doctor_list, name='user_doctor_list'),
    path('user/hospitals/', views.user_hospital_list, name='user_hospital_list'),

]
