function showMessage() {
    alert("Welcome to the Chronic Disease Recommender!");
}
