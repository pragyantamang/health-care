from django import forms
from .models import UserProfile
from .models import Doctor, Hospital

class RegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = UserProfile
        fields = ['name', 'email', 'age', 'gender', 'disease', 'password']

class LoginForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    
class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['name', 'email', 'password', 'age', 'gender']
        widgets = {
            'password': forms.PasswordInput(),
        }

    
class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = '__all__'

class HospitalForm(forms.ModelForm):
    class Meta:
        model = Hospital
        fields = '__all__'
        widgets = {
            'specialties': forms.CheckboxSelectMultiple()
        }

