from django.contrib import admin
from .models import Specialty

admin.site.register(Specialty)
