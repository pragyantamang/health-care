from django.apps import AppConfig


class ChronicConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chronic'
