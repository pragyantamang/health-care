from django.db import models

GENDER_CHOICES = [
    ('M', 'Male'),
    ('F', 'Female'),
    ('O', 'Other'),
]

DISEASE_CHOICES = [
    ('diabetes', 'Diabetes'),
    ('hypertension', 'Hypertension'),
    ('asthma', 'Asthma'),
    ('cancer', 'Cancer'),
]

HOSPITAL_CHOICES = [
    ('bir', 'Bir Hospital'),
    ('nmc', 'Nepal Medical College Hospital'),
    ('motherland', 'Motherland Hospital'),
    ('om', 'Om Hospital'),
]

class UserProfile(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    age = models.PositiveIntegerField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    disease = models.CharField(max_length=50, choices=DISEASE_CHOICES)
    password = models.CharField(max_length=100)
    



class Hospital(models.Model):
    name = models.CharField(max_length=100)
    specialties = models.ManyToManyField('Specialty')
    contact_number = models.CharField(max_length=50)
    location = models.CharField(max_length=255)
    image = models.ImageField(upload_to='hospital_images/', blank=True, null=True)

  
class Doctor(models.Model):
    name = models.CharField(max_length=100)
    specialty = models.CharField(max_length=50, choices=DISEASE_CHOICES)
    qualification = models.CharField(max_length=100)
    hospital_affiliation = models.CharField(max_length=50, choices=HOSPITAL_CHOICES)
    contact_number = models.CharField(max_length=50)
    image = models.ImageField(upload_to='doctor_images/', blank=True, null=True)


class Specialty(models.Model):
    name = models.CharField(max_length=50, choices=DISEASE_CHOICES, unique=True)


class Specialties(models.Model):
    name = models.CharField(max_length=50, choices=DISEASE_CHOICES, unique=True)
    
    def __str__(self):
        return self.name
