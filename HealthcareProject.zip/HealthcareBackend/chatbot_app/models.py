from django.db import models
from django.contrib.auth.models import User

class Disease(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class UserProfile(models.Model):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    age = models.PositiveIntegerField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    diseases = models.ManyToManyField(Disease, blank=True)

    def __str__(self):
        return self.user.username

class Doctor(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    speciality = models.CharField(max_length=100)
    qualification = models.CharField(max_length=200)
    hospital_affiliation = models.CharField(max_length=200)
    contact_no = models.CharField(max_length=20)

    def __str__(self):
        return self.name
